package dev.flr.visuals;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import org.joml.Vector3f;

public final class GameEvents {
    private static double acc;
    private static boolean swapped;
    private static int cooldown;

    public static void tick(ClientTickEvent.Post e) {
        Minecraft mc = Minecraft.getInstance();
        while (FlrKeys.MASTER.consumeClick()) {
            Config.master = !Config.master;
            Config.save();
            if (mc.player != null) mc.player.displayClientMessage(Component.literal("FLR Visuals: " + (Config.master ? "ON" : "OFF")), true);
        }
        while (FlrKeys.MENU.consumeClick()) mc.setScreen(new CosmeticsScreen());
        while (FlrKeys.SOUND.consumeClick()) mc.getSoundManager().play(SimpleSoundInstance.forUI(FlrSounds.TRACK, 1.0f));

        LocalPlayer self = mc.player;
        if (self == null || mc.level == null) return;
        autoTotem(mc, self);
        if (!Config.master || mc.isPaused()) return;
        effects(mc, self);
    }

    /** Падение выше 10 блоков: достаём тотем бессмертия в offhand (если он есть в инвентаре). */
    private static void autoTotem(Minecraft mc, LocalPlayer p) {
        if (cooldown > 0) cooldown--;
        if (p.onGround() || p.isInWater()) {
            swapped = false;
            return;
        }
        if (!Config.autoTotem || swapped || cooldown > 0 || p.isSpectator() || p.isFallFlying() || p.getAbilities().flying) return;
        if (p.fallDistance <= 10) return;
        if (p.getOffhandItem().is(Items.TOTEM_OF_UNDYING)) {
            swapped = true;
            return;
        }
        if (mc.gameMode == null || p.containerMenu != p.inventoryMenu) return;
        Inventory inv = p.getInventory();
        for (int i = 0; i < 36; i++) {
            if (!inv.getItem(i).is(Items.TOTEM_OF_UNDYING)) continue;
            int slot = i < 9 ? i + 36 : i; // hotbar -> 36..44 в меню инвентаря
            mc.gameMode.handleInventoryMouseClick(p.inventoryMenu.containerId, slot, 40, ClickType.SWAP, p);
            swapped = true;
            cooldown = 10;
            p.displayClientMessage(Component.literal("Auto Totem"), true);
            return;
        }
    }

    private static ParticleOptions option() {
        int c = Config.color();
        return switch (Config.particleType) {
            case 0 -> ParticleTypes.END_ROD;
            case 1 -> ParticleTypes.HEART;
            case 2 -> ParticleTypes.GLOW;
            case 3 -> ParticleTypes.SNOWFLAKE;
            case 4 -> ParticleTypes.ELECTRIC_SPARK;
            default -> new DustParticleOptions(new Vector3f((c >> 16 & 255) / 255f, (c >> 8 & 255) / 255f, (c & 255) / 255f), 1f);
        };
    }

    private static void effects(Minecraft mc, LocalPlayer self) {
        int budget = Config.effectiveBudget();
        RandomSource r = mc.level.random;

        // искры при ударе
        if (Config.hitSparks && self.swinging && self.swingTime == 0) {
            HitResult hr = mc.hitResult;
            if (hr instanceof EntityHitResult) {
                Vec3 l = hr.getLocation();
                for (int i = 0; i < 6; i++)
                    mc.level.addParticle(ParticleTypes.ELECTRIC_SPARK, l.x, l.y, l.z,
                            (r.nextDouble() - 0.5) * 0.4, r.nextDouble() * 0.3, (r.nextDouble() - 0.5) * 0.4);
            }
        }
        if (budget <= 0 || !(Config.aura || Config.trail || Config.halo || Config.ambient)) return;
        acc += budget * 0.02;
        int n = (int) acc;
        acc -= n;
        if (n <= 0) return;

        double maxD2 = (double) Config.maxDistance * Config.maxDistance;
        ParticleOptions o = option();
        double s = Config.scale;
        for (Player pl : mc.level.players()) {
            boolean me = pl == self;
            if (pl.isInvisible() || pl.isSpectator()) continue;
            if (!me && (!Config.others || pl.distanceToSqr(self) > maxD2)) continue;
            double h = pl.getBbHeight();
            boolean moving = pl.getDeltaMovement().horizontalDistanceSqr() > 0.002;
            for (int i = 0; i < n; i++) {
                double a = r.nextDouble() * Math.PI * 2;
                if (Config.aura)
                    mc.level.addParticle(o, pl.getX() + Math.cos(a) * 0.6 * s, pl.getY() + r.nextDouble() * h, pl.getZ() + Math.sin(a) * 0.6 * s, 0, 0.02, 0);
                if (Config.halo && i == 0)
                    mc.level.addParticle(o, pl.getX() + Math.cos(a) * 0.25 * s, pl.getY() + h + 0.25 * s, pl.getZ() + Math.sin(a) * 0.25 * s, 0, 0, 0);
                if (Config.trail && moving)
                    mc.level.addParticle(o, pl.getX() + (r.nextDouble() - 0.5) * 0.4, pl.getY() + 0.1, pl.getZ() + (r.nextDouble() - 0.5) * 0.4, 0, 0.01, 0);
                if (Config.ambient && me)
                    mc.level.addParticle(ParticleTypes.GLOW, pl.getX() + (r.nextDouble() - 0.5) * 8, pl.getY() + r.nextDouble() * 3, pl.getZ() + (r.nextDouble() - 0.5) * 8,
                            (r.nextDouble() - 0.5) * 0.01, (r.nextDouble() - 0.5) * 0.01, (r.nextDouble() - 0.5) * 0.01);
            }
        }
    }
}
