package dev.flr.visuals;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.client.resources.PlayerSkin;
import net.minecraft.util.Mth;
import net.minecraft.world.level.material.FogType;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.client.event.RenderGuiEvent;
import net.neoforged.neoforge.client.event.ViewportEvent;

public final class ClientEvents {
    private static int frames;
    private static long windowStart = System.nanoTime();

    public static void registerKeys(RegisterKeyMappingsEvent e) {
        e.register(FlrKeys.MENU);
        e.register(FlrKeys.MASTER);
        e.register(FlrKeys.SOUND);
    }

    public static void addLayers(EntityRenderersEvent.AddLayers e) {
        for (PlayerSkin.Model skin : e.getSkins()) {
            var r = e.getSkin(skin);
            if (r instanceof PlayerRenderer pr) pr.addLayer(new CosmeticsLayer(pr));
        }
    }

    public static void gui(RenderGuiEvent.Post e) {
        frames++;
        long now = System.nanoTime();
        if (now - windowStart >= 500_000_000L) {
            Config.fps = (int) (frames * 1_000_000_000.0 / (now - windowStart));
            frames = 0;
            windowStart = now;
        }
        Minecraft mc = Minecraft.getInstance();
        if (!Config.master || !Config.hud || mc.options.hideGui || mc.screen != null) return;
        GuiGraphics g = e.getGuiGraphics();
        String text = "FLR  " + Config.fps + " FPS";
        int w = mc.font.width(text);
        int c = Config.color();
        g.fill(5, 5, 5 + w + 10, 20, 0x99101018);
        g.fill(5, 5, 7, 20, c);
        g.drawString(mc.font, text, 11, 9, c, false);
    }

    public static void fogColor(ViewportEvent.ComputeFogColor e) {
        if (!Config.master || Config.fogTint <= 0 || e.getCamera().getFluidInCamera() != FogType.NONE) return;
        int c = Config.color();
        float t = (float) Config.fogTint * 0.6f;
        e.setRed(Mth.lerp(t, e.getRed(), (c >> 16 & 255) / 255f));
        e.setGreen(Mth.lerp(t, e.getGreen(), (c >> 8 & 255) / 255f));
        e.setBlue(Mth.lerp(t, e.getBlue(), (c & 255) / 255f));
    }

    public static void fogRender(ViewportEvent.RenderFog e) {
        if (!Config.master || Config.fogDensity <= 0 || e.getType() != FogType.NONE) return;
        float far = Mth.lerp((float) Config.fogDensity, 220f, 28f);
        e.setNearPlaneDistance(far * 0.1f);
        e.setFarPlaneDistance(far);
        e.setCanceled(true);
    }
}
