package dev.flr.visuals;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/**
 * Крылья/нимб/плащ. Все детали крепятся к ЧАСТЯМ МОДЕЛИ (body/head) через translateAndRotate,
 * поэтому они сами следуют за приседанием и наклоном и больше не "улетают" вверх.
 */
public class CosmeticsLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {
    private static final ResourceLocation WHITE = ResourceLocation.fromNamespaceAndPath(FlrVisuals.MOD_ID, "textures/misc/white.png");
    /** Angel, Demon, Dark, Crystal, Energy */
    private static final int[] PALETTE = {0xFFE9E9F2, 0xFFC0304A, 0xFF5B4BB0, 0xFF8FD8EA, 0xFF40FFE0};
    private static final Map<UUID, WingModel.State> STATES = new HashMap<>();

    public CosmeticsLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent) {
        super(parent);
    }

    @Override
    public void render(PoseStack ps, MultiBufferSource buf, int light, AbstractClientPlayer p, float limb, float limbAmt,
                       float pt, float age, float yaw, float pitch) {
        if (!Config.master || p.isInvisible() || p.isSpectator()) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        boolean self = p == mc.player;
        double d2 = mc.player.distanceToSqr(p);
        if (!self && (!Config.others || d2 > (double) Config.maxDistance * Config.maxDistance)) return;
        boolean lod = d2 > 576 || (Config.autoPerf && Config.fps < 35);
        int theme = Config.color();
        int lit = LightTexture.pack(Math.max(LightTexture.block(light), 7), LightTexture.sky(light));
        boolean sneak = p.isCrouching();

        if (Config.wings) {
            WingModel.State st = STATES.computeIfAbsent(p.getUUID(), k -> new WingModel.State());
            long now = System.nanoTime();
            float dt = st.lastNanos == 0 ? 0.016f : Math.min(0.1f, (now - st.lastNanos) / 1e9f);
            st.lastNanos = now;
            st.lastSeenMs = now / 1_000_000L;
            boolean air = !p.onGround() && !p.isInWater();
            float mv = Math.min(1f, limbAmt);
            float tSpread = (air || p.isFallFlying()) ? 1f : sneak ? 0.15f : 0.3f + 0.35f * mv;
            float tAmp = air ? 0.9f : 0.12f + 0.2f * mv;
            float tSpeed = (air ? 6f : 1.5f + 2f * mv) * (float) Config.speed;
            st.update(dt, tSpread, tAmp, tSpeed, sneak ? 1f : 0f);
            if (STATES.size() > 64) STATES.values().removeIf(s -> now / 1_000_000L - s.lastSeenMs > 10_000L);

            int type = Config.wingStyle;
            int accent = Config.wingTint ? theme : PALETTE[Math.max(0, Math.min(4, type))];
            float size = (float) (Config.scale * Config.wingSize);
            boolean add = WingModel.additive(type);
            ps.pushPose();
            getParentModel().body.translateAndRotate(ps);
            VertexConsumer vc = buf.getBuffer(add ? RenderType.lightning() : RenderType.entityTranslucent(WHITE));
            PoseStack.Pose pose = ps.last();
            WingModel.Sink sink = (xyz, argb) -> emit(vc, pose, xyz, argb, add, lit);
            WingModel.build(type, -1, size, st, accent, lod, sink);
            WingModel.build(type, 1, size, st, accent, lod, sink);
            ps.popPose();
        }

        if (Config.cape) {
            ps.pushPose();
            getParentModel().body.translateAndRotate(ps);
            VertexConsumer vc = buf.getBuffer(RenderType.entityTranslucent(WHITE));
            PoseStack.Pose pose = ps.last();
            float bend = Mth.clamp(limbAmt * 0.3f + (sneak ? 0.12f : 0f), 0f, 0.45f);
            float sway = (float) Math.sin(age * 0.08f) * 0.02f;
            float w = 0.25f * (float) Config.scale;
            int segs = lod ? 3 : 6;
            float[] q = new float[12];
            int[] c = new int[4];
            for (int j = 0; j < segs; j++) {
                float f0 = j / (float) segs, f1 = (j + 1) / (float) segs;
                float y0 = 0.02f + f0 * 0.85f, y1 = 0.02f + f1 * 0.85f;
                float z0 = 0.2f + bend * f0 * f0 + sway * f0, z1 = 0.2f + bend * f1 * f1 + sway * f1;
                set(q, 0, -w, y0, z0); set(q, 3, w, y0, z0); set(q, 6, w, y1, z1); set(q, 9, -w, y1, z1);
                int ca = shade(theme, 0.75f - 0.25f * f0, 225), cb = shade(theme, 0.75f - 0.25f * f1, 225);
                c[0] = ca; c[1] = ca; c[2] = cb; c[3] = cb;
                emit(vc, pose, q, c, false, lit);
            }
            ps.popPose();
        }

        if (Config.halo) {
            ps.pushPose();
            getParentModel().head.translateAndRotate(ps);
            VertexConsumer vc = buf.getBuffer(RenderType.lightning());
            PoseStack.Pose pp = ps.last();
            float y = -0.62f + (float) Math.sin(age * 0.1f) * 0.02f;
            float r0 = 0.20f * (float) Config.scale, r1 = 0.29f * (float) Config.scale;
            int n = lod ? 12 : 24;
            float[] q = new float[12];
            int[] c = {shade(theme, 1f, 235), shade(theme, 1f, 235), shade(theme, 0.8f, 235), shade(theme, 0.8f, 235)};
            for (int i = 0; i < n; i++) {
                double a0 = i * Math.PI * 2 / n, a1 = (i + 1) * Math.PI * 2 / n;
                set(q, 0, (float) (r0 * Math.cos(a0)), y, (float) (r0 * Math.sin(a0)));
                set(q, 3, (float) (r1 * Math.cos(a0)), y, (float) (r1 * Math.sin(a0)));
                set(q, 6, (float) (r1 * Math.cos(a1)), y, (float) (r1 * Math.sin(a1)));
                set(q, 9, (float) (r0 * Math.cos(a1)), y, (float) (r0 * Math.sin(a1)));
                emit(vc, pp, q, c, true, lit);
            }
            ps.popPose();
        }
    }


    private static void set(float[] a, int o, float x, float y, float z) {
        a[o] = x; a[o + 1] = y; a[o + 2] = z;
    }

    private static int shade(int argb, float k, int alpha) {
        int r = Math.min(255, (int) ((argb >> 16 & 255) * k)), g = Math.min(255, (int) ((argb >> 8 & 255) * k)), b = Math.min(255, (int) ((argb & 255) * k));
        return alpha << 24 | r << 16 | g << 8 | b;
    }

    private static void emit(VertexConsumer vc, PoseStack.Pose pose, float[] v, int[] argb, boolean add, int light) {
        float ax = v[3] - v[0], ay = v[4] - v[1], az = v[5] - v[2];
        float bx = v[6] - v[0], by = v[7] - v[1], bz = v[8] - v[2];
        float nx = ay * bz - az * by, ny = az * bx - ax * bz, nz = ax * by - ay * bx;
        float len = (float) Math.sqrt(nx * nx + ny * ny + nz * nz);
        if (len < 1e-6f) { nx = 0; ny = 0; nz = 1; } else { nx /= len; ny /= len; nz /= len; }
        if (nz < 0) { nx = -nx; ny = -ny; nz = -nz; }
        for (int k = 0; k < 4; k++) {
            VertexConsumer b = vc.addVertex(pose.pose(), v[k * 3], v[k * 3 + 1], v[k * 3 + 2]).setColor(argb[k]);
            if (!add) b.setUv(0f, 0f).setOverlay(OverlayTexture.NO_OVERLAY).setLight(light).setNormal(pose, nx, ny, nz);
        }
    }
}
