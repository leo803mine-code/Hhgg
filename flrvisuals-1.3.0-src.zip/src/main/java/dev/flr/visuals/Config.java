package dev.flr.visuals;

import java.awt.Color;
import java.io.Reader;
import java.io.Writer;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;
import net.minecraft.client.Minecraft;
import net.minecraft.client.ParticleStatus;
import net.neoforged.fml.loading.FMLPaths;

public final class Config {
    public static boolean master = true, wings = true, halo = true, cape = false, ambient = false, aura = false,
            trail = false, hitSparks = false, others = true, hud = true, autoPerf = true, wingTint = false,
            autoTotem = true;
    public static int theme = 0, wingStyle = 0, particleType = 0, particleBudget = 40, maxDistance = 48;
    public static double scale = 1.0, wingSize = 1.0, speed = 1.0, hue = 0.55, fogDensity = 0.0, fogTint = 0.0;
    public static transient int fps = 60;

    public static final String[] THEME_NAMES = {"Aqua", "Violet", "Rose", "Gold", "Rainbow", "Custom"};
    public static final int[] THEME_COLORS = {0x35E0FF, 0xA06BFF, 0xFF5C9E, 0xFFC94D};
    public static final String[] WING_NAMES = WingModel.NAMES;
    public static final String[] PARTICLE_NAMES = {"End rod", "Heart", "Glow", "Snow", "Spark", "Dust"};

    /** Основной цвет темы, ARGB. */
    public static int color() {
        int rgb;
        if (theme < THEME_COLORS.length) rgb = THEME_COLORS[theme];
        else if (theme == 4) rgb = Color.HSBtoRGB((System.currentTimeMillis() % 8000L) / 8000f * (float) Math.max(speed, 0.2), 0.6f, 1f);
        else rgb = Color.HSBtoRGB((float) hue, 0.65f, 1f);
        return 0xFF000000 | (rgb & 0xFFFFFF);
    }

    public static int effectiveBudget() {
        int b = particleBudget;
        if (autoPerf && fps < 40) b /= 3;
        try {
            if (Minecraft.getInstance().options.particles().get() == ParticleStatus.MINIMAL) b /= 2;
        } catch (Exception ignored) {
        }
        return b;
    }

    public static void reset() {
        master = true; wings = true; halo = true; cape = false; ambient = false; aura = false; trail = false;
        hitSparks = false; others = true; hud = true; autoPerf = true; wingTint = false; autoTotem = true;
        theme = 0; wingStyle = 0; particleType = 0; particleBudget = 40; maxDistance = 48;
        scale = 1.0; wingSize = 1.0; speed = 1.0; hue = 0.55; fogDensity = 0.0; fogTint = 0.0;
        save();
    }

    private static Path file() {
        return FMLPaths.CONFIGDIR.get().resolve("flrvisuals.properties");
    }

    private static Field[] fields() {
        return java.util.Arrays.stream(Config.class.getDeclaredFields()).filter(f -> {
            int m = f.getModifiers();
            return Modifier.isStatic(m) && !Modifier.isFinal(m) && !Modifier.isTransient(m);
        }).toArray(Field[]::new);
    }

    public static void load() {
        Path p = file();
        if (!Files.exists(p)) return;
        Properties pr = new Properties();
        try (Reader r = Files.newBufferedReader(p)) {
            pr.load(r);
        } catch (Exception e) {
            return;
        }
        for (Field f : fields()) {
            String v = pr.getProperty(f.getName());
            if (v == null) continue;
            try {
                v = v.trim();
                if (f.getType() == boolean.class) f.setBoolean(null, Boolean.parseBoolean(v));
                else if (f.getType() == int.class) f.setInt(null, Integer.parseInt(v));
                else if (f.getType() == double.class) f.setDouble(null, Double.parseDouble(v));
            } catch (Exception ignored) {
            }
        }
        theme = Math.max(0, Math.min(THEME_NAMES.length - 1, theme));
        wingStyle = Math.max(0, Math.min(WingModel.TYPES - 1, wingStyle));
        particleType = Math.max(0, Math.min(PARTICLE_NAMES.length - 1, particleType));
    }

    public static void save() {
        Properties pr = new Properties();
        for (Field f : fields()) {
            try {
                pr.setProperty(f.getName(), String.valueOf(f.get(null)));
            } catch (Exception ignored) {
            }
        }
        try (Writer w = Files.newBufferedWriter(file())) {
            pr.store(w, "FLR Visuals");
        } catch (Exception ignored) {
        }
    }
}
