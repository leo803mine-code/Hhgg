package dev.flr.visuals;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.DoubleConsumer;
import java.util.function.DoubleSupplier;
import java.util.function.IntConsumer;
import java.util.function.IntSupplier;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class CosmeticsScreen extends Screen {
    private static final int W = 450, H = 276, SIDE = 108, ROWH = 27;
    private static final String[] TABS = {"Wings", "Effects", "Performance", "Utility"};

    private final List<List<Row>> pages = new ArrayList<>();
    private int tab;
    private float tabY = -1, openAnim, tabFade = 1f;
    private long last;
    private Row dragging;
    private int px, py, cx, cw, top;

    public CosmeticsScreen() {
        super(Component.literal("FLR VISUALS"));
    }

    // ---------- строки ----------
    private static final class Row {
        final String label;
        final int type; // 0 toggle, 1 choice, 2 slider, 3 button
        BooleanSupplier bget; Consumer<Boolean> bset;
        String[] names; IntSupplier iget; IntConsumer iset;
        DoubleSupplier dget; DoubleConsumer dset; double min, max; boolean isInt;
        Runnable action;
        float anim, hov;

        Row(String label, int type) { this.label = label; this.type = type; }
    }

    private static Row toggle(String l, BooleanSupplier g, Consumer<Boolean> s) {
        Row r = new Row(l, 0); r.bget = g; r.bset = s; r.anim = g.getAsBoolean() ? 1f : 0f; return r;
    }
    private static Row choice(String l, String[] n, IntSupplier g, IntConsumer s) {
        Row r = new Row(l, 1); r.names = n; r.iget = g; r.iset = s; return r;
    }
    private static Row slider(String l, double min, double max, boolean isInt, DoubleSupplier g, DoubleConsumer s) {
        Row r = new Row(l, 2); r.min = min; r.max = max; r.isInt = isInt; r.dget = g; r.dset = s; return r;
    }
    private static Row button(String l, Runnable a) {
        Row r = new Row(l, 3); r.action = a; return r;
    }

    @Override
    protected void init() {
        if (!pages.isEmpty()) return;
        pages.add(List.of(
                toggle("Wings", () -> Config.wings, v -> Config.wings = v),
                choice("Wing style", Config.WING_NAMES, () -> Config.wingStyle, v -> Config.wingStyle = v),
                slider("Wing size", 0.5, 1.6, false, () -> Config.wingSize, v -> Config.wingSize = v),
                toggle("Use theme colour", () -> Config.wingTint, v -> Config.wingTint = v),
                toggle("Halo", () -> Config.halo, v -> Config.halo = v),
                toggle("Cape", () -> Config.cape, v -> Config.cape = v),
                choice("Theme", Config.THEME_NAMES, () -> Config.theme, v -> Config.theme = v),
                slider("Custom hue", 0, 1, false, () -> Config.hue, v -> Config.hue = v)));
        pages.add(List.of(
                toggle("Aura", () -> Config.aura, v -> Config.aura = v),
                toggle("Trail", () -> Config.trail, v -> Config.trail = v),
                toggle("Hit sparks", () -> Config.hitSparks, v -> Config.hitSparks = v),
                toggle("Ambient fireflies", () -> Config.ambient, v -> Config.ambient = v),
                choice("Particle type", Config.PARTICLE_NAMES, () -> Config.particleType, v -> Config.particleType = v),
                slider("Effect scale", 0.5, 2.0, false, () -> Config.scale, v -> Config.scale = v),
                slider("Fog tint", 0, 1, false, () -> Config.fogTint, v -> Config.fogTint = v),
                slider("Fog density", 0, 1, false, () -> Config.fogDensity, v -> Config.fogDensity = v)));
        pages.add(List.of(
                toggle("Show on other players", () -> Config.others, v -> Config.others = v),
                toggle("Auto performance", () -> Config.autoPerf, v -> Config.autoPerf = v),
                toggle("FPS counter", () -> Config.hud, v -> Config.hud = v),
                slider("Particle budget", 0, 100, true, () -> Config.particleBudget, v -> Config.particleBudget = (int) Math.round(v)),
                slider("Max distance", 8, 96, true, () -> Config.maxDistance, v -> Config.maxDistance = (int) Math.round(v)),
                slider("Animation speed", 0.2, 3.0, false, () -> Config.speed, v -> Config.speed = v)));
        pages.add(List.of(
                toggle("Auto Totem (fall > 10 blocks)", () -> Config.autoTotem, v -> Config.autoTotem = v),
                toggle("FLR Visuals enabled", () -> Config.master, v -> Config.master = v),
                button("Reset to defaults", Config::reset)));
    }

    // ---------- утилиты рисования ----------
    private static float k(float dt, float rate) { return 1f - (float) Math.exp(-rate * dt); }

    private static int rgba(int rgb, float a) {
        int a8 = Math.max(8, Math.min(255, (int) (a * 255f)));
        return a8 << 24 | (rgb & 0xFFFFFF);
    }

    private static int mix(int a, int b, float t) {
        int r = (int) ((a >> 16 & 255) * (1 - t) + (b >> 16 & 255) * t);
        int g = (int) ((a >> 8 & 255) * (1 - t) + (b >> 8 & 255) * t);
        int bl = (int) ((a & 255) * (1 - t) + (b & 255) * t);
        return r << 16 | g << 8 | bl;
    }

    private static void rrect(GuiGraphics g, int x, int y, int w, int h, int r, int c) {
        r = Math.min(r, Math.min(w, h) / 2);
        if (r <= 0) { g.fill(x, y, x + w, y + h, c); return; }
        g.fill(x, y + r, x + w, y + h - r, c);
        for (int i = 0; i < r; i++) {
            double d = r - i - 0.5;
            int in = (int) Math.round(r - Math.sqrt(r * r - d * d));
            g.fill(x + in, y + i, x + w - in, y + i + 1, c);
            g.fill(x + in, y + h - i - 1, x + w - in, y + h - i, c);
        }
    }

    private static boolean in(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    private int rowY(int j) { return top + j * ROWH; }

    // ---------- рендер ----------
    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        long now = System.nanoTime();
        float dt = last == 0 ? 0.016f : Math.min(0.05f, (now - last) / 1e9f);
        last = now;
        openAnim += (1f - openAnim) * k(dt, 11f);
        tabFade += (1f - tabFade) * k(dt, 14f);
        float e = openAnim;
        int accent = Config.color() & 0xFFFFFF;

        g.fill(0, 0, width, height, rgba(0x04050A, 0.60f * e));
        px = (width - W) / 2;
        py = (height - H) / 2 + (int) ((1f - e) * 16);
        cx = px + SIDE + 8;
        cw = W - SIDE - 20;
        top = py + 48;

        rrect(g, px - 1, py - 1, W + 2, H + 2, 10, rgba(accent, 0.30f * e));
        rrect(g, px, py, W, H, 9, rgba(0x11121B, 0.97f * e));
        rrect(g, px + 6, py + 6, SIDE - 6, H - 12, 7, rgba(0x191B28, e));

        g.drawString(font, "FLR VISUALS", px + 16, py + 16, rgba(accent, e), false);
        g.drawString(font, "v1.3.0", px + 16, py + 27, rgba(0x6C7090, e), false);

        // вкладки + плавный индикатор
        float target = py + 46 + tab * 26;
        tabY = tabY < 0 ? target : tabY + (target - tabY) * k(dt, 16f);
        rrect(g, px + 11, (int) tabY, SIDE - 16, 22, 6, rgba(accent, 0.20f * e));
        rrect(g, px + 11, (int) tabY + 4, 2, 14, 1, rgba(accent, e));
        for (int i = 0; i < TABS.length; i++) {
            boolean h = in(mx, my, px + 11, py + 46 + i * 26, SIDE - 16, 22);
            int col = i == tab ? 0xFFFFFF : h ? 0xC4C8E0 : 0x8A8EAA;
            g.drawString(font, TABS[i], px + 20, py + 52 + i * 26, rgba(col, e), false);
        }

        // статус
        int sy = py + H - 28;
        boolean on = Config.master;
        rrect(g, px + 11, sy, SIDE - 16, 18, 6, rgba(in(mx, my, px + 11, sy, SIDE - 16, 18) ? 0x262941 : 0x1F2133, e));
        float pulse = 0.65f + 0.35f * (float) Math.sin(now / 3.0e8);
        rrect(g, px + 18, sy + 6, 6, 6, 3, rgba(on ? 0x4CE08A : 0xE0524C, on ? pulse * e : e));
        g.drawString(font, on ? "ACTIVE" : "OFF", px + 30, sy + 5, rgba(on ? 0xCFFFE3 : 0xFFCFCF, e), false);

        // ряды
        List<Row> rows = pages.get(tab);
        for (int j = 0; j < rows.size(); j++) {
            Row r = rows.get(j);
            int y = rowY(j), h = ROWH - 3;
            boolean hv = in(mx, my, cx, y, cw, h) || r == dragging;
            r.hov += ((hv ? 1f : 0f) - r.hov) * k(dt, 18f);
            float fade = Math.min(1f, e * tabFade * (1f + 0.0f * j));
            rrect(g, cx, y, cw, h, 6, rgba(mix(0x181A27, 0x24273A, r.hov), fade));
            g.drawString(font, r.label, cx + 10, y + (h - 8) / 2, rgba(mix(0xB4B8D2, 0xFFFFFF, r.hov), fade), false);
            drawControl(g, r, y, h, accent, fade, dt, hv);
        }
    }

    private void drawControl(GuiGraphics g, Row r, int y, int h, int accent, float a, float dt, boolean hv) {
        int right = cx + cw - 10;
        switch (r.type) {
            case 0 -> {
                r.anim += ((r.bget.getAsBoolean() ? 1f : 0f) - r.anim) * k(dt, 18f);
                int pw = 30, ph = 14, x = right - pw, yy = y + (h - ph) / 2;
                rrect(g, x, yy, pw, ph, 7, rgba(mix(0x383B52, accent, r.anim), a));
                int kx = x + 2 + Math.round(r.anim * (pw - ph));
                rrect(g, kx, yy + 2, ph - 4, ph - 4, 5, rgba(mix(0xA0A4BE, 0xFFFFFF, r.anim), a));
            }
            case 1 -> {
                int pw = 112, x = right - pw, ph = 16, yy = y + (h - ph) / 2;
                rrect(g, x, yy, pw, ph, 8, rgba(mix(0x22243A, accent, hv ? 0.22f : 0.12f), a));
                String t = r.names[Math.max(0, Math.min(r.names.length - 1, r.iget.getAsInt()))];
                g.drawString(font, "<", x + 6, yy + 4, rgba(0x7E83A6, a), false);
                g.drawString(font, ">", x + pw - 12, yy + 4, rgba(0x7E83A6, a), false);
                g.drawString(font, t, x + (pw - font.width(t)) / 2, yy + 4, rgba(accent, a), false);
            }
            case 2 -> {
                int tx = sliderX(), tw = sliderW(), ty = y + h / 2 - 2;
                double v = r.dget.getAsDouble();
                float f = (float) ((v - r.min) / (r.max - r.min));
                f = Math.max(0f, Math.min(1f, f));
                rrect(g, tx, ty, tw, 4, 2, rgba(0x343750, a));
                rrect(g, tx, ty, Math.max(4, (int) (tw * f)), 4, 2, rgba(accent, a));
                rrect(g, tx + (int) (tw * f) - 4, ty - 3, 8, 10, 4, rgba(0xFFFFFF, a));
                String s = r.isInt ? String.valueOf(Math.round(v)) : String.format("%.2f", v);
                g.drawString(font, s, right - font.width(s), y + (h - 8) / 2, rgba(0xB4B8D2, a), false);
            }
            default -> {
                int pw = 108, x = right - pw, ph = 16, yy = y + (h - ph) / 2;
                rrect(g, x, yy, pw, ph, 8, rgba(mix(0x2A2D44, accent, hv ? 0.45f : 0.22f), a));
                g.drawString(font, "Reset", x + (pw - font.width("Reset")) / 2, yy + 4, rgba(0xFFFFFF, a), false);
            }
        }
    }

    private int sliderX() { return cx + cw - 10 - 150; }
    private int sliderW() { return 100; }

    // ---------- ввод ----------
    @Override
    public boolean mouseClicked(double mx, double my, int btn) {
        for (int i = 0; i < TABS.length; i++) {
            if (in(mx, my, px + 11, py + 46 + i * 26, SIDE - 16, 22)) {
                if (tab != i) { tab = i; tabFade = 0f; }
                return true;
            }
        }
        if (in(mx, my, px + 11, py + H - 28, SIDE - 16, 18)) {
            Config.master = !Config.master;
            Config.save();
            return true;
        }
        List<Row> rows = pages.get(tab);
        for (int j = 0; j < rows.size(); j++) {
            Row r = rows.get(j);
            if (!in(mx, my, cx, rowY(j), cw, ROWH - 3)) continue;
            switch (r.type) {
                case 0 -> r.bset.accept(!r.bget.getAsBoolean());
                case 1 -> {
                    int n = r.names.length;
                    r.iset.accept(Math.floorMod(r.iget.getAsInt() + (btn == 1 ? -1 : 1), n));
                }
                case 2 -> { dragging = r; applySlider(r, mx); }
                default -> r.action.run();
            }
            Config.save();
            return true;
        }
        return super.mouseClicked(mx, my, btn);
    }

    private void applySlider(Row r, double mx) {
        double f = Math.max(0, Math.min(1, (mx - sliderX()) / sliderW()));
        double v = r.min + f * (r.max - r.min);
        r.dset.accept(r.isInt ? Math.round(v) : Math.round(v * 100.0) / 100.0);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int btn, double dx, double dy) {
        if (dragging != null) { applySlider(dragging, mx); return true; }
        return super.mouseDragged(mx, my, btn, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int btn) {
        if (dragging != null) { dragging = null; Config.save(); }
        return super.mouseReleased(mx, my, btn);
    }

    @Override
    public void renderBackground(GuiGraphics g, int mx, int my, float pt) {
        // свой фон рисуется в render(), без размытия ванили
    }

    @Override
    public void onClose() {
        Config.save();
        super.onClose();
    }

    @Override
    public boolean isPauseScreen() { return false; }
}
